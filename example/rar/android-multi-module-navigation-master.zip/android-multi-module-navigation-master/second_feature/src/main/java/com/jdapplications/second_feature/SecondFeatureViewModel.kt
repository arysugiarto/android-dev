package com.jdapplications.second_feature

import androidx.lifecycle.ViewModel;

class SecondFeatureViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
