# android-multi-module-navigation
A showcase app for the new navigation component with a multiple module project

Check out the article on Medium:

https://medium.com/@hartwich.daniel/multi-module-navigation-with-the-android-architecture-component-82ed028fa1d9


![](https://raw.githubusercontent.com/dhartwich1991/android-multi-module-navigation/master/Screen%20Shot%202018-06-28%20at%2009.54.47.png)
