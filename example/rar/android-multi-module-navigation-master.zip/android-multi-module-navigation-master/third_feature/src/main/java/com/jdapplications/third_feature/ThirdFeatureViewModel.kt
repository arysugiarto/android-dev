package com.jdapplications.third_feature

import androidx.lifecycle.ViewModel;

class ThirdFeatureViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
