package com.jdapplications.third_feature

import androidx.lifecycle.ViewModel;

class ThirdFeatureFragmentSecondScreenViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
