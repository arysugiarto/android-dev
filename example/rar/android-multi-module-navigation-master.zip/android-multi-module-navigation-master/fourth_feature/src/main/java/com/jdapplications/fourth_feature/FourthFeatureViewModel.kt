package com.jdapplications.fourth_feature

import androidx.lifecycle.ViewModel;

class FourthFeatureViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
