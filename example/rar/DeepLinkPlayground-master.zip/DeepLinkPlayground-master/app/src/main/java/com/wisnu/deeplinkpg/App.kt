package com.wisnu.deeplinkpg

import android.app.Application

/**
 * Created by wisnu on 9/1/18
 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
    }

}