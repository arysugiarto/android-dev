package com.wisnu.launcher.main

interface Application {
    fun onCreate(launcher: Launcher)
}
