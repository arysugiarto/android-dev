package com.wisnu.kurn.core_utils

object Constant {
    val RANDOM = 2
}