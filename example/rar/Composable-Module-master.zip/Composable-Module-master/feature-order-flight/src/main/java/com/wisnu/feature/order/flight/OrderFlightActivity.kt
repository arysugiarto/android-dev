package com.wisnu.feature.order.flight

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class OrderFlightActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_flight)
    }
}
