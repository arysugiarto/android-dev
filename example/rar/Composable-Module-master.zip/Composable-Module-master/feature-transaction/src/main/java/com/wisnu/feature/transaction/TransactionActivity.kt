package com.wisnu.feature.transaction

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class TransactionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transaction)

        // update comment here 2
    }
}
