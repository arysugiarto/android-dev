package com.wisnu.feature.orderbus

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class OrderBusActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_bus)
        // put comment
    }
}
