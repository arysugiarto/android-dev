/*
 * Created by Muhammad Utsman on 8/18/19 3:55 AM
 * Copyright (c) 2019 . All rights reserved.
 * Last modified 8/18/19 3:55 AM
 */

package com.utsman.recycling.paged.extentions

data class LoaderIdentifierId(internal var layoutRes: Int? = null,
                              var idLoader: Int? = null,
                              var idTextError: Int? = null)